genome_version=`ls *.gff*|awk -F. '{print $1}'`
#prepare .gff file for annotation
echo \#\#FASTA >> *.gff*
cat *.fa >> *.gff*
#modify annotation config file
echo `ls *.gff*|awk -F. '{print $1}'`.genome:`ls *.gff*|awk -F. '{print $1}'`>> ./software_package/snpEff/snpEff.config 
echo data_dir=./software_package/snpEff/data/`ls *.gff*|awk -F. '{print $1}'`>>./software_package/snpEff/snpEff.config
#copy .gff file to the specific folder
cp *.gff* ./software_package/snpEff/data
cd ./software_package/snpEff/data
mkdir $genome_version
mv *.gff* genes.gff
mv genes.gff ./$genome_version
cd ..
#build genome for annotation 
java -jar ./snpEff.jar build -gff3 -v $genome_version
cd ../.. 
#annotate the mutant specific homozygous variants
java -jar ./software_package/snpEff/snpEff.jar ann -c ./software_package/snpEff/snpEff.config $genome_version -i vcf -o vcf mutant_specific_snp_homozygous.vcf >mutant_specific_snp_homozygous_annotated.vcf
java -jar ./software_package/snpEff/snpEff.jar ann -c ./software_package/snpEff/snpEff.config $genome_version -i vcf -o vcf mutant_specific_indel_homozygous.vcf >mutant_specific_indel_homozygous_annotated.vcf
#select the annotated variants with high or moderate impact. 4 lists will be output.
cat mutant_specific_snp_homozygous_annotated.vcf |grep -i "high">mutant_specific_snp_homozygous_annotated_high_impact.list
cat mutant_specific_snp_homozygous_annotated.vcf |grep -i "moderate">mutant_specific_snp_homozygous_annotated_moderate_impact.list
cat mutant_specific_indel_homozygous_annotated.vcf|grep -i "high"> mutant_specific_indel_homozygous_annotated_high_impact.list
cat mutant_specific_indel_homozygous_annotated.vcf|grep -i "moderate">mutant_specific_indel_homozygous_annotated_moderate_impact.list

