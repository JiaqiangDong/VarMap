#invoke R to draw the snp/indel index plots
#May 7,2018, by Yaping Feng
args<-commandArgs(TRUE) #readin customer GSA filtered pathogenic genotype
name<-as.character(args[1])
library(ggplot2)
namein<-paste(name,"_specific_snp.index",sep='')
a <- read.table(file=namein)
a$averaged.SNP.index <- filter(a$V5, rep(1/5, 5), sides=2)
#pdf("SNPindex-chr.pdf",width=9,height=6)
a<-na.omit(a)
p=ggplot(a,aes(x=V2/1000000,y=averaged.SNP.index)) + geom_point(alpha=0.25,cex=0.5) + theme_bw() +
facet_wrap(~V1, scales = "free") +
scale_y_continuous(limits = c(0, 1)) +
labs(x="Chromosome position (MB)" , y="Averged SNP index")
ggsave(filename="SNPindex-chr.pdf",p,width = 9, height = 6)
while (!is.null(dev.list()))  dev.off()

namein<-paste(name,"_specific_indel.index",sep='')
a <- read.table(file=namein)
a$averaged.SNP.index <- filter(a$V5, rep(1/5, 5), sides=2)
#pdf("SNPindex-chr.pdf",width=9,height=6)
a<-na.omit(a)
p=ggplot(a,aes(x=V2/1000000,y=averaged.SNP.index)) + geom_point(alpha=0.25,cex=0.5) + theme_bw() +
facet_wrap(~V1, scales = "free") +
scale_y_continuous(limits = c(0, 1)) +
labs(x="Chromosome position (MB)" , y="Averged indel index")
ggsave(filename="INDELindex-chr.pdf",p,width = 9, height = 6)
while (!is.null(dev.list()))  dev.off()

