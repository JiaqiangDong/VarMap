#!/bin/bash
###Job name
#PBS -N Align_GATK_Plot_RNA
###specify queue
#PBS -q batch
###number of nodes and processor requested
#PBS -l nodes=1
###memory requested
#PBS -l vmem=100gb
###maximum time the job will be allowed to run
#PBS -l walltime=1000:00:00
###console output
#PBS -o RNA_result.out
###join the output and error files
#PBS -j oe
###send notifications at the beginning, end, and if job aborts
#PBS -m bea
###email to send the notifications
#PBS -M ******@gmail.com
#change to user's own email

path=/ingens/home/jqdong/pipeline_last_test_20180703
#path to working directory

REFS=Zea_mays.AGPv3.31.dna.genome.fa
#reference genome filename

sample1=mutant
#sample1 name
read1=JMJDR19_S14_R1_001.fastq
#filename of the paired end read1 of sample1 (mutant)
read2=JMJDR19_S14_R2_001.fastq
#filename of the paired end read2 of sample1 (mutant)

sample2=wide_type
#sample2 name
read3=JMJDR21_S5_R1_001.fastq
#filename of the paired end read1 of sample2 (wide type)
read4=JMJDR21_S5_R2_001.fastq
#filename of the paired end read2 of sample2 (wide type)

$path/software_package/samtools faidx $path/$REFS

java -jar $path/software_package/picard.jar CreateSequenceDictionary R=$path/$REFS O=$path/`echo "${REFS%.*}"`.dict

#analysis for sample1(mutant)
mkdir $path/fastqc_$sample1

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample1 $path/$read1 $path/$read2

java -jar $path/software_package/trimmomatic-0.36.jar PE $path/$read1 $path/$read2 $path/paired_$read1 $path/unpaired_$read1 $path/paired_$read2 $path/unpaired_$read2 ILLUMINACLIP:$path/software_package/trimmomatic_adapters/TruSeq3-PE.fa:2:30:10:2:TRUE LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample1 $path/paired_$read1 $path/paired_$read2

genomeDir_1pass=$path/${sample1}_genomeDir_1pass
mkdir $genomeDir_1pass
$path/software_package/STAR --runMode genomeGenerate --genomeDir $genomeDir_1pass --genomeFastaFiles $path/$REFS --runThreadN 16

runDir1=$path/${sample1}_runDir1
mkdir $runDir1
cd $runDir1
$path/software_package/STAR --genomeDir $genomeDir_1pass --readFilesIn $path/paired_$read1 $path/paired_$read2 --runThreadN 16 --outFileNamePrefix ${sample1}
cd $path

genomeDir_2pass=$path/${sample1}_genomeDir_2pass
mkdir $genomeDir_2pass
$path/software_package/STAR --runMode genomeGenerate --genomeDir $genomeDir_2pass --genomeFastaFiles $path/$REFS --sjdbFileChrStartEnd $runDir1/${sample1}SJ.out.tab --sjdbOverhang 75 --runThreadN 16

runDir2=$path/${sample1}_runDir2
mkdir $runDir2
cd  $runDir2
$path/software_package/STAR --genomeDir $genomeDir_2pass --readFilesIn $path/paired_$read1 $path/paired_$read2 --runThreadN 16 --outFileNamePrefix ${sample1}

java -jar $path/software_package/picard.jar AddOrReplaceReadGroups I=$runDir2/${sample1}Aligned.out.sam O=$runDir2/rg_added_sorted_${sample1}.bam SO=coordinate RGID=`head -1 $path/$read1|awk -F: '{print $NF}'` RGLB=$sample1 RGPU=`head -1 $path/$read1|awk -F: '{print $NF}'` RGPL=illumina RGSM=$sample1

java -jar $path/software_package/picard.jar MarkDuplicates INPUT=$runDir2/rg_added_sorted_${sample1}.bam OUTPUT=$runDir2/rg_added_sorted_rudmp_${sample1}.bam METRICS_FILE=$runDir2/rg_added_sorted_rudmp_${sample1}.bam.metrics

java -jar $path/software_package/picard.jar BuildBamIndex INPUT=$runDir2/rg_added_sorted_rudmp_${sample1}.bam
$path/software_package/samtools index $runDir2/rg_added_sorted_rudmp_${sample1}.bam

java -jar $path/software_package/GenomeAnalysisTK.jar -T SplitNCigarReads -R $path/$REFS -I $runDir2/rg_added_sorted_rudmp_${sample1}.bam -o $runDir2/${sample1}_split.bam -rf ReassignOneMappingQuality -RMQF 255 -RMQT 60 -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 8 -T HaplotypeCaller -R $path/$REFS -I $runDir2/${sample1}_split.bam --dontUseSoftClippedBases -stand_call_conf 20.0 -o $runDir2/aln_paired_sorted_rudmp_raw_${sample1}.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $runDir2/aln_paired_sorted_rudmp_raw_${sample1}.vcf -window 35 -cluster 3 -filter "QD<2.00||FS>30.000" --filterName "fail" -o $runDir2/aln_paired_sorted_rudmp_raw_${sample1}_filtered.vcf -U ALL

cat $runDir2/aln_paired_sorted_rudmp_raw_${sample1}_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$runDir2/selected_for_BQSR_${sample1}.vcf

cat $runDir2/aln_paired_sorted_rudmp_raw_${sample1}_filtered.vcf|awk '$7!="fail" {print $0}'>>$runDir2/selected_for_BQSR_${sample1}.vcf

java -jar $path/software_package/picard.jar SortVcf I=$runDir2/selected_for_BQSR_${sample1}.vcf O=$runDir2/selected_for_BQSR_${sample1}_sorted.vcf
cat $runDir2/selected_for_BQSR_${sample1}_sorted.vcf |sed 's/Number=R/Number=./' >$runDir2/selected_for_BQSR_${sample1}_sorted_modified.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T BaseRecalibrator -R $path/$REFS -I $runDir2/${sample1}_split.bam -knownSites:name,VCF $runDir2/selected_for_BQSR_${sample1}_sorted_modified.vcf -o $runDir2/selected_for_BQSR_${sample1}_modified_recal_data.table -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T PrintReads -R $path/$REFS -I $runDir2/${sample1}_split.bam -BQSR $runDir2/selected_for_BQSR_${sample1}_modified_recal_data.table -o $runDir2/aln_paired_sorted_rudmp_recal_${sample1}.bam -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 8 -T HaplotypeCaller -R $path/$REFS -I $runDir2/aln_paired_sorted_rudmp_recal_${sample1}.bam --dontUseSoftClippedBases -stand_call_conf 20.0 -o $runDir2/aln_paired_sorted_rudmp_recal_${sample1}.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $runDir2/aln_paired_sorted_rudmp_recal_${sample1}.vcf -selectType SNP -o $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp.vcf -window 35 -cluster 3 -filterName FS -filter "FS>30.000" -filterName QD -filter "QD<2.00" -o $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $runDir2/aln_paired_sorted_rudmp_recal_${sample1}.vcf -selectType INDEL -o $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel.vcf -window 35 -cluster 3 -filterName FS -filter "FS>30.000" -filterName QD -filter "QD<2.00" -o $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered.vcf -U ALL

cat $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'> $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf

cat $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf

cat $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf

cat $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf

bgzip $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf

tabix $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf.gz

bgzip $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf

tabix $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf.gz


#analysis for sample2 (wide type)
mkdir $path/fastqc_$sample2

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample2 $path/$read3 $path/$read4

java -jar $path/software_package/trimmomatic-0.36.jar PE $path/$read3 $path/$read4 $path/paired_$read3 $path/unpaired_$read3 $path/paired_$read4 $path/unpaired_$read4 ILLUMINACLIP:$path/software_package/trimmomatic_adapters/TruSeq3-PE.fa:2:30:10:2:TRUE LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample2 $path/paired_$read3 $path/paired_$read4

genomeDir_3pass=$path/${sample2}_genomeDir_1pass
mkdir $genomeDir_3pass
$path/software_package/STAR --runMode genomeGenerate --genomeDir $genomeDir_3pass --genomeFastaFiles $path/$REFS --runThreadN 16

runDir3=$path/${sample2}_runDir1
mkdir $runDir3
cd $runDir3
$path/software_package/STAR --genomeDir $genomeDir_3pass --readFilesIn $path/paired_$read3 $path/paired_$read4 --runThreadN 16 --outFileNamePrefix ${sample2}
cd $path

genomeDir_4pass=$path/${sample2}_genomeDir_2pass
mkdir $genomeDir_4pass
$path/software_package/STAR --runMode genomeGenerate --genomeDir $genomeDir_4pass --genomeFastaFiles $path/$REFS --sjdbFileChrStartEnd $runDir3/${sample2}SJ.out.tab --sjdbOverhang 75 --runThreadN 16

runDir4=$path/${sample2}_runDir2
mkdir $runDir4
cd  $runDir4
$path/software_package/STAR --genomeDir $genomeDir_4pass --readFilesIn $path/paired_$read3 $path/paired_$read4 --runThreadN 16 --outFileNamePrefix ${sample2}

java -jar $path/software_package/picard.jar AddOrReplaceReadGroups I=$runDir4/${sample2}Aligned.out.sam O=$runDir4/rg_added_sorted_${sample2}.bam SO=coordinate RGID=`head -1 $path/$read3|awk -F: '{print $NF}'` RGLB=$sample2 RGPU=`head -1 $path/$read3|awk -F: '{print $NF}'` RGPL=illumina RGSM=$sample2

java -jar $path/software_package/picard.jar MarkDuplicates INPUT=$runDir4/rg_added_sorted_${sample2}.bam OUTPUT=$runDir4/rg_added_sorted_rudmp_${sample2}.bam METRICS_FILE=$runDir4/rg_added_sorted_rudmp_${sample2}.bam.metrics

java -jar $path/software_package/picard.jar BuildBamIndex INPUT=$runDir4/rg_added_sorted_rudmp_${sample2}.bam
$path/software_package/samtools index $runDir4/rg_added_sorted_rudmp_${sample2}.bam

java -jar $path/software_package/GenomeAnalysisTK.jar -T SplitNCigarReads -R $path/$REFS -I $runDir4/rg_added_sorted_rudmp_${sample2}.bam -o $runDir4/${sample2}_split.bam -rf ReassignOneMappingQuality -RMQF 255 -RMQT 60 -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 8 -T HaplotypeCaller -R $path/$REFS -I $runDir4/${sample2}_split.bam --dontUseSoftClippedBases -stand_call_conf 20.0 -o $runDir4/aln_paired_sorted_rudmp_raw_${sample2}.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $runDir4/aln_paired_sorted_rudmp_raw_${sample2}.vcf -window 35 -cluster 3 -filter "QD<2.00||FS>30.000" --filterName "fail" -o $runDir4/aln_paired_sorted_rudmp_raw_${sample2}_filtered.vcf -U ALL

cat $runDir4/aln_paired_sorted_rudmp_raw_${sample2}_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$runDir4/selected_for_BQSR_${sample2}.vcf

cat $runDir4/aln_paired_sorted_rudmp_raw_${sample2}_filtered.vcf|awk '$7!="fail" {print $0}'>>$runDir4/selected_for_BQSR_${sample2}.vcf

java -jar $path/software_package/picard.jar SortVcf I=$runDir4/selected_for_BQSR_${sample2}.vcf O=$runDir4/selected_for_BQSR_${sample2}_sorted.vcf
cat $runDir4/selected_for_BQSR_${sample2}_sorted.vcf |sed 's/Number=R/Number=./' >$runDir4/selected_for_BQSR_${sample2}_sorted_modified.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T BaseRecalibrator -R $path/$REFS -I $runDir4/${sample2}_split.bam -knownSites:name,VCF $runDir4/selected_for_BQSR_${sample2}_sorted_modified.vcf -o $runDir4/selected_for_BQSR_${sample2}_modified_recal_data.table -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T PrintReads -R $path/$REFS -I $runDir4/${sample2}_split.bam -BQSR $runDir4/selected_for_BQSR_${sample2}_modified_recal_data.table -o $runDir4/aln_paired_sorted_rudmp_recal_${sample2}.bam -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 8 -T HaplotypeCaller -R $path/$REFS -I $runDir4/aln_paired_sorted_rudmp_recal_${sample2}.bam --dontUseSoftClippedBases -stand_call_conf 20.0 -o $runDir4/aln_paired_sorted_rudmp_recal_${sample2}.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $runDir4/aln_paired_sorted_rudmp_recal_${sample2}.vcf -selectType SNP -o $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp.vcf -window 35 -cluster 3 -filterName FS -filter "FS>30.000" -filterName QD -filter "QD<2.00" -o $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $runDir4/aln_paired_sorted_rudmp_recal_${sample2}.vcf -selectType INDEL -o $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel.vcf -U ALL

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel.vcf -window 35 -cluster 3 -filterName FS -filter "FS>30.000" -filterName QD -filter "QD<2.00" -o $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered.vcf -U ALL

cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'> $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf

cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf

cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf

cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf

cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf
cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf

cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf
cat $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf

bgzip $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf
tabix $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf.gz

bgzip $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf
tabix $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf.gz

#select sample1 specific variants and plot variant index plot
$path/software_package/vcftools_0.1.13/bin/vcf-isec -a -f -c $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf.gz $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf.gz>$path/${sample1}_specific_indel.vcf

$path/software_package/vcftools_0.1.13/bin/vcf-isec -a -f -c $runDir2/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf.gz $runDir4/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf.gz>$path/${sample1}_specific_snp.vcf

cat $path/${sample1}_specific_snp.vcf|awk '{if (substr($1, 1, 3) !="con") print $0}'|awk '{if (substr($1, 1, 3) !="sca") print $0}'|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index.awk>$path/${sample1}_specific_snp.index

cat $path/${sample1}_specific_indel.vcf|awk '{if (substr($1, 1, 3) !="con") print $0}'|awk '{if (substr($1, 1, 3) !="sca") print $0}'|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index.awk>$path/${sample1}_specific_indel.index

cd $path
Rscript ./software_package/plotsnp.r ${sample1}

#select homozygous sample1 specific variants
cat $path/${sample1}_specific_snp.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/${sample1}_specific_snp_homozygous.vcf
cat $path/${sample1}_specific_snp.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$path/${sample1}_specific_snp_homozygous.vcf
cat $path/${sample1}_specific_indel.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/${sample1}_specific_indel_homozygous.vcf
cat $path/${sample1}_specific_indel.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$path/${sample1}_specific_indel_homozygous.vcf

