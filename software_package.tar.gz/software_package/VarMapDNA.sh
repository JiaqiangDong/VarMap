#!/bin/bash
###Job name
#PBS -N Align_GATK_Plot_DNA
###specify queue
#PBS -q batch
###number of nodes and processor requested
#PBS -l nodes=1
###memory requested
#PBS -l vmem=100gb
###maximum time the job will be allowed to run
#PBS -l walltime=1000:00:00
###console output
#PBS -o DNA_result.out
###join the output and error files
#PBS -j oe
###send notifications at the beginning, end, and if job aborts
#PBS -m bea
###email to send the notifications
#PBS -M ******@gmail.com
#change to user's own email

path=/ingens/home/jqdong/pipeline_last_test
#path to working directory

REFS=F_vesca_H4_V4.1.fa
#reference genome filename

sample1=mutant
#sample1 name
read1=AZ4-NonRunnerD_trim_R1_001.fastq
#filename of the paired end read1 of sample1 (mutant)
read2=AZ4-NonRunnerD_trim_R2_001.fastq
#filename of the paired end read2 of sample1 (mutant)

sample2=wide_type
#sample2 name
read3=AZ3-RunnerD_trim_R1_001.fastq
#filename of the paired end read1 of sample2 (wide type)
read4=AZ3-RunnerD_trim_R2_001.fastq
#filename of the paired end read2 of sample2 (wide type)

$path/software_package/bwa index $path/$REFS

$path/software_package/samtools faidx $path/$REFS

java -jar $path/software_package/picard.jar CreateSequenceDictionary R=$path/$REFS O=$path/`echo "${REFS%.*}"`.dict

#analysis for sample1(mutant)
mkdir $path/fastqc_$sample1

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample1 $path/$read1 $path/$read2

java -jar $path/software_package/trimmomatic-0.36.jar PE $path/$read1 $path/$read2 $path/paired_$read1 $path/unpaired_$read1 $path/paired_$read2 $path/unpaired_$read2 ILLUMINACLIP:$path/software_package/trimmomatic_adapters/TruSeq3-PE.fa:2:30:10:2:TRUE LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample1 $path/paired_$read1 $path/paired_$read2

mkdir $path/$sample1

$path/software_package/bwa mem -M -t 16 $path/$REFS $path/paired_$read1 $path/paired_$read2 >$path/$sample1/aln_paired_${sample1}.sam

java -jar $path/software_package/picard.jar AddOrReplaceReadGroups I=$path/$sample1/aln_paired_${sample1}.sam O=$path/$sample1/rg_added_sorted_${sample1}.bam SO=coordinate RGID=`head -1 $path/$read1|awk -F: '{print $3":"$NF}'` RGLB=$sample1 RGPU=`head -1 $path/$read1|awk -F: '{print $3":"$NF}'` RGPL=illumina RGSM=$sample1

java -jar $path/software_package/picard.jar MarkDuplicates INPUT=$path/$sample1/rg_added_sorted_${sample1}.bam OUTPUT=$path/$sample1/aln_paired_sorted_rudmp_${sample1}.bam METRICS_FILE=$path/$sample1/aln_paired_sorted_rudmp.bam_${sample1}.metrics

java -jar $path/software_package/picard.jar BuildBamIndex INPUT=$path/$sample1/aln_paired_sorted_rudmp_${sample1}.bam
$path/software_package/samtools index $path/$sample1/aln_paired_sorted_rudmp_${sample1}.bam

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 16 -T HaplotypeCaller -R $path/$REFS -I $path/$sample1/aln_paired_sorted_rudmp_${sample1}.bam --genotyping_mode DISCOVERY -stand_call_conf 30 -o $path/$sample1/aln_paired_sorted_rudmp_raw_${sample1}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_raw_${sample1}.vcf -selectType SNP -o $path/$sample1/aln_paired_sorted_rudmp_raw_snp_${sample1}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_raw_snp_${sample1}.vcf -filter "QD<2.00||FS>60.000||SOR>3.00||MQ<40.00||MQRankSum<-12.500||ReadPosRankSum<-8.000" --filterName "fail" -o $path/$sample1/aln_paired_sorted_rudmp_raw_snp_${sample1}_filtered.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_raw_${sample1}.vcf -selectType INDEL -o $path/$sample1/aln_paired_sorted_rudmp_raw_indel_${sample1}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_raw_indel_${sample1}.vcf -filter "QD<2.00||FS>200.000||ReadPosRankSum<-20.000||SOR>10.00" --filterName "fail" -o $path/$sample1/aln_paired_sorted_rudmp_raw_indel_${sample1}_filtered.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_raw_snp_${sample1}_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/$sample1/selected_for_BQSR_${sample1}.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_raw_snp_${sample1}_filtered.vcf|awk '$7!="fail" {print $0}'>>$path/$sample1/selected_for_BQSR_${sample1}.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_raw_indel_${sample1}_filtered.vcf|awk '$7!="fail" {print $0}'>>$path/$sample1/selected_for_BQSR_${sample1}.vcf

java -jar $path/software_package/picard.jar SortVcf I=$path/$sample1/selected_for_BQSR_${sample1}.vcf O=$path/$sample1/selected_for_BQSR_${sample1}_sorted.vcf

cat $path/$sample1/selected_for_BQSR_${sample1}_sorted.vcf |sed 's/Number=R/Number=./' >$path/$sample1/selected_for_BQSR_${sample1}_sorted_modified.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T BaseRecalibrator -R $path/$REFS -I $path/$sample1/aln_paired_sorted_rudmp_${sample1}.bam -knownSites:name,VCF $path/$sample1/selected_for_BQSR_${sample1}_sorted_modified.vcf -o $path/$sample1/selected_for_BQSR_${sample1}_modified_recal_data.table
 
java -jar $path/software_package/GenomeAnalysisTK.jar -T PrintReads -R $path/$REFS -I $path/$sample1/aln_paired_sorted_rudmp_${sample1}.bam -BQSR $path/$sample1/selected_for_BQSR_${sample1}_modified_recal_data.table -o $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}.bam

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 16 -T HaplotypeCaller -R $path/$REFS -I $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}.bam --genotyping_mode DISCOVERY -stand_call_conf 30 -o $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}.vcf -selectType SNP -o $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp.vcf -filter "QD<2.00||FS>60.000||SOR>3.00||MQ<40.00||MQRankSum<-12.500||ReadPosRankSum<-8.000" --filterName "fail" -o $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}.vcf -selectType INDEL -o $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel.vcf -filter "QD<2.00||FS>200.000||ReadPosRankSum<-20.000||SOR>10.00" --filterName "fail" -o $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'> $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf

cat $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf

bgzip $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf

tabix $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf.gz

bgzip $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf

tabix $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf.gz


#analysis for sample2 (wide type)
mkdir $path/fastqc_$sample2

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample2 $path/$read3 $path/$read4

java -jar $path/software_package/trimmomatic-0.36.jar PE $path/$read3 $path/$read4 $path/paired_$read3 $path/unpaired_$read3 $path/paired_$read4 $path/unpaired_$read4 ILLUMINACLIP:$path/software_package/trimmomatic_adapters/TruSeq3-PE.fa:2:30:10:2:TRUE LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36

$path/software_package/FastQC/fastqc -o $path/fastqc_$sample2 $path/paired_$read3 $path/paired_$read4

mkdir $path/$sample2

$path/software_package/bwa mem -M -t 16 $path/$REFS $path/paired_$read3 $path/paired_$read4 >$path/$sample2/aln_paired_${sample2}.sam

java -jar $path/software_package/picard.jar AddOrReplaceReadGroups I=$path/$sample2/aln_paired_${sample2}.sam O=$path/$sample2/rg_added_sorted_${sample2}.bam SO=coordinate RGID=`head -1 $path/$read3|awk -F: '{print $3":"$NF}'` RGLB=$sample2 RGPU=`head -1 $path/$read3|awk -F: '{print $3":"$NF}'` RGPL=illumina RGSM=$sample2

java -jar $path/software_package/picard.jar MarkDuplicates INPUT=$path/$sample2/rg_added_sorted_${sample2}.bam OUTPUT=$path/$sample2/aln_paired_sorted_rudmp_${sample2}.bam METRICS_FILE=$path/$sample2/aln_paired_sorted_rudmp.bam_${sample2}.metrics

java -jar $path/software_package/picard.jar BuildBamIndex INPUT=$path/$sample2/aln_paired_sorted_rudmp_${sample2}.bam

$path/software_package/samtools index $path/$sample2/aln_paired_sorted_rudmp_${sample2}.bam

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 16 -T HaplotypeCaller -R $path/$REFS -I $path/$sample2/aln_paired_sorted_rudmp_${sample2}.bam --genotyping_mode DISCOVERY -stand_call_conf 30 -o $path/$sample2/aln_paired_sorted_rudmp_raw_${sample2}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_raw_${sample2}.vcf -selectType SNP -o $path/$sample2/aln_paired_sorted_rudmp_raw_snp_${sample2}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_raw_snp_${sample2}.vcf -filter "QD<2.00||FS>60.000||SOR>3.00||MQ<40.00||MQRankSum<-12.500||ReadPosRankSum<-8.000" --filterName "fail" -o $path/$sample2/aln_paired_sorted_rudmp_raw_snp_${sample2}_filtered.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_raw_${sample2}.vcf -selectType INDEL -o $path/$sample2/aln_paired_sorted_rudmp_raw_indel_${sample2}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_raw_indel_${sample2}.vcf -filter "QD<2.00||FS>200.000||ReadPosRankSum<-20.000||SOR>10.00" --filterName "fail" -o $path/$sample2/aln_paired_sorted_rudmp_raw_indel_${sample2}_filtered.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_raw_snp_${sample2}_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/$sample2/selected_for_BQSR_${sample2}.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_raw_snp_${sample2}_filtered.vcf|awk '$7!="fail" {print $0}'>>$path/$sample2/selected_for_BQSR_${sample2}.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_raw_indel_${sample2}_filtered.vcf|awk '$7!="fail" {print $0}'>>$path/$sample2/selected_for_BQSR_${sample2}.vcf

java -jar $path/software_package/picard.jar SortVcf I=$path/$sample2/selected_for_BQSR_${sample2}.vcf O=$path/$sample2/selected_for_BQSR_${sample2}_sorted.vcf

cat $path/$sample2/selected_for_BQSR_${sample2}_sorted.vcf |sed 's/Number=R/Number=./' >$path/$sample2/selected_for_BQSR_${sample2}_sorted_modified.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T BaseRecalibrator -R $path/$REFS -I $path/$sample2/aln_paired_sorted_rudmp_${sample2}.bam -knownSites:name,VCF $path/$sample2/selected_for_BQSR_${sample2}_sorted_modified.vcf -o $path/$sample2/selected_for_BQSR_${sample2}_modified_recal_data.table
 
java -jar $path/software_package/GenomeAnalysisTK.jar -T PrintReads -R $path/$REFS -I $path/$sample2/aln_paired_sorted_rudmp_${sample2}.bam -BQSR $path/$sample2/selected_for_BQSR_${sample2}_modified_recal_data.table -o $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}.bam

java -jar $path/software_package/GenomeAnalysisTK.jar -nct 16 -T HaplotypeCaller -R $path/$REFS -I $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}.bam --genotyping_mode DISCOVERY -stand_call_conf 30 -o $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}.vcf -selectType SNP -o $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp.vcf -filter "QD<2.00||FS>60.000||SOR>3.00||MQ<40.00||MQRankSum<-12.500||ReadPosRankSum<-8.000" --filterName "fail" -o $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T SelectVariants -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}.vcf -selectType INDEL -o $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel.vcf

java -jar $path/software_package/GenomeAnalysisTK.jar -T VariantFiltration -R $path/$REFS -V $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel.vcf -filter "QD<2.00||FS>200.000||ReadPosRankSum<-20.000||SOR>10.00" --filterName "fail" -o $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'> $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered.vcf|awk -f $path/software_package/extract_based_on_DP10.awk>>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf

cat $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf

bgzip $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf

tabix $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf.gz

bgzip $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf

tabix $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf.gz


#select sample1 specific variants and plot variant index plot
$path/software_package/vcftools_0.1.13/bin/vcf-isec -a -f -c $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_snp_filtered_DP10.vcf.gz $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_snp_filtered_DP10_homozygous.vcf.gz>$path/${sample1}_specific_snp.vcf

$path/software_package/vcftools_0.1.13/bin/vcf-isec -a -f -c $path/$sample1/aln_paired_sorted_rudmp_recal_${sample1}_indel_filtered_DP10.vcf.gz $path/$sample2/aln_paired_sorted_rudmp_recal_${sample2}_indel_filtered_DP10_homozygous.vcf.gz>$path/${sample1}_specific_indel.vcf

cat $path/${sample1}_specific_snp.vcf|awk '{if (substr($1, 1, 3) !="con") print $0}'|awk '{if (substr($1, 1, 3) !="sca") print $0}'|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index.awk>$path/${sample1}_specific_snp.index

cat $path/${sample1}_specific_indel.vcf|awk '{if (substr($1, 1, 3) !="con") print $0}'|awk '{if (substr($1, 1, 3) !="sca") print $0}'|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index.awk>$path/${sample1}_specific_indel.index

cd $path
Rscript ./software_package/plotsnp.r ${sample1}

#select sample1 specific homozygous variants 
cat $path/${sample1}_specific_snp.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/${sample1}_specific_snp_homozygous.vcf

cat $path/${sample1}_specific_snp.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$path/${sample1}_specific_snp_homozygous.vcf

cat $path/${sample1}_specific_indel.vcf|awk '{if (substr($1, 1, 1) == "#") print $0}'>$path/${sample1}_specific_indel_homozygous.vcf

cat $path/${sample1}_specific_indel.vcf|awk '$7=="PASS"{print $0}'|awk -f $path/software_package/extract_snp_index_larger_than_0.9.awk>>$path/${sample1}_specific_indel_homozygous.vcf 



